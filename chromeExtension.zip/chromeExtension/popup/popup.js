
$(function () {
  let openHome = $('#openHome')

  $('#login').click(function () {
    chrome.identity.getAuthToken({"interactive":true},function (token) {
      alert(token);
    })
  });

  openHome.click(function () {
    chrome.runtime.sendMessage({
      action: 'open home page'
    })
  })
})
